Extract in /home/$USER/.themes

A Dark theme with green-red hover-active effects
