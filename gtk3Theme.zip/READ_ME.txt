Extract in /home/$USER/.themes

A Dark theme with green-red hover-active effects

Might require too add it in /usr/share/themes
to be detected by other apps.
