#!/bin/bash 

echo -e "  $(date +%d/%m/%y\ %H:%M)"
