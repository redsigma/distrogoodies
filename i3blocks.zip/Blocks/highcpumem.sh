#!/bin/bash 

# Cpu=$(ps -eo cmd,%mem,%cpu --sort=-%cpu | head -n2 | tail -n1)
# awk '{print $1}'


Cpu=$(ps -eo %cpu --sort=-%cpu | head -n2 | tail -n1 )
Mem=$(ps -eo %mem --sort=-%cpu | head -n2 | tail -n1 )

# Cpu=$(ps -eo %cpu --sort=-%cpu | head -n2 | tail -n1)

if [ -z "$1"];then
	echo "empty" 
fi

case "$1" in 
    "-m" )
         echo " $Mem"
        ;;
    "-c" )
         echo " $Cpu"
        ;;
esac 

